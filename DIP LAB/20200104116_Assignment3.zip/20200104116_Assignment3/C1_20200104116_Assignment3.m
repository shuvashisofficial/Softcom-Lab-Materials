close all;
prompt = 'Enter the sigma value: ';
sigma = input(prompt);
S = rgb2gray(imread('bean.jpg'));

% Define the 3x3 kernel
X = zeros(3,3);
Y = zeros(3,3);
for i=1:3
    counter=-1;
    for j=1:3
        X(i,j)=counter;
        Y(j,i)=counter;
        counter=counter+1;
    end
end
temp1=1/(2*pi*(sigma^2));
temp2=(-((X.^2)+(Y.^2))/(2*(sigma^2)));
gauss=temp1*exp(temp2);

% Pad the image with zeros on the borders
[row, col] = size(S);
R=uint8(zeros(row+2,col+2));
row=row+2;
col=col+2;
R(2:row-1,2:col-1)=S;
T=R;
R=double(R);

% Apply the Gaussian filter using the 3x3 kernel
for i = 1:row-2
   for j = 1:col-2 
      N = R(i:i+2, j:j+2);
      t = sum(sum(N.*gauss)); 
      T(i+1,j+1) = t;
   end
end

figure; imshow(S);
F=uint8(T(2:row-1,2:col-1)); 
figure;imshow(F, [min(F(:)), max(F(:))]);
